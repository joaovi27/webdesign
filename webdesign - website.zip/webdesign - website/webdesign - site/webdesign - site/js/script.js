//Captura ano atual



//Funcao debounce da biblioteca Lodash js 
//reduz acionamento demasiado da funcao de animacao

const debounce = function(func, wait, immediate){
  let timeout;
  return function(...args) {
    const context =this;
    const later = function(){
      timeout = null;
      if (!immediate) func.apply(context, args);
    };
    const callnow = immediate && !timeout;
    clearTimeout(timeout);
    timeout = setTimeout(later,wait);
    if(callnow) func.apply(context, args);
  };
};


/* animacao scroll*/

const target = document.querySelectorAll('[data-anime]');
const animationclass = 'animate';

function animeScroll() {
  const windowtop = window.pageYOffset + ((window.innerHeight*3) / 4); //inicia animacao com 3/4 da vh 
  target.forEach(function(element) {
    if((windowtop) > element.offsetTop) {
      element.classList.add(animationclass); //add animacao ao elemento
    } else {
      element.classList.remove(animationclass);
    }
  })
}

animeScroll();


if(target.length) {
// monitora acao de scroll da janela para executar funcao 
window.addEventListener('scroll', debounce(function(){
  animeScroll();
}, 200 )); //utilizacao debounce para otimizacao de acionamentos
}

